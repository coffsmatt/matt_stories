# Matt's Stories — Firebase edition

This version fixes the microphone problem: it is a normal Firebase-hosted HTTPS page, not an Apps Script HTML page. It records up to 20 minutes, flashes during the last minute, then saves the audio in Drive and appends a recording row to a Google Sheet.

It is deliberately a small static site. Firebase only hosts the page. The audio goes directly from the browser to Google Drive, and the log row goes directly to Google Sheets; there is no database, server, or API secret.

## What you need

- The Firebase project ID is already set to `matts-stories` (project number `1088618610221`).
- A Google account: `coffsmatt@gmail.com`.
- Git and Node.js 20 or newer on your computer. Confirm with `node --version`.
- This folder's contents copied into your GitHub repository: `https://github.com/coffsmatt/matt_stories`.

## 1. Enable the Google APIs

While signed in as `coffsmatt@gmail.com`, open the Google Cloud console for **matts-stories**. In **APIs & Services > Library**, enable these three APIs:

1. **Google Drive API**
2. **Google Sheets API**
3. **Google People API** is *not* required.

The app uses the standard Google user-info endpoint, so no separate user-info API needs enabling.

## 2. Configure the OAuth consent screen

1. In **APIs & Services > OAuth consent screen**, choose **External** (a normal Gmail account is not a Workspace internal account).
2. Give the app the name **Matt’s Stories** and use `coffsmatt@gmail.com` for the support email and developer contact email.
3. Leave the app in **Testing** for now.
4. Under **Test users**, add `coffsmatt@gmail.com`.

Leaving this as a testing-only personal app is intentional. Do not publish it or add other users until you are ready to deal with Google’s OAuth-verification requirements.

## 3. Create the web OAuth client

1. In **APIs & Services > Credentials**, choose **Create credentials > OAuth client ID**.
2. Choose **Web application** and call it `Matt's Stories web`.
3. You will add the authorised JavaScript origins after Firebase gives you the Hosting URL. It is fine to create the client with no origins for now.
4. Copy the value labelled **Client ID**. It ends in `.apps.googleusercontent.com`.
5. Put it into `public/config.js`, replacing the whole placeholder value beginning `PASTE-YOUR-...`.

Do **not** create, copy, or use a client secret. This is a browser-only site and client IDs are expected to be visible in its source.

## 4. Put the project in GitHub

In PowerShell, from this project directory:

```powershell
git init
git add .
git commit -m "Create Matt's Stories recorder"
git branch -M main
git remote add origin https://github.com/coffsmatt/matt_stories.git
git push -u origin main
```

If the GitHub repository already contains a README, clone that repository first, copy these files into the clone, then run `git add .`, `git commit`, and `git push`. Do not run `git init` inside an existing clone.

## 5. Deploy to Firebase Hosting

Install the Firebase command-line tool once:

```powershell
npm install -g firebase-tools
firebase login
```

From the project root, deploy the static site:

```powershell
firebase deploy --only hosting
```

Firebase prints URLs like `https://matts-stories.web.app` and `https://matts-stories.firebaseapp.com`. Open the `.web.app` address once so that you know it is working.

## 6. Add the Firebase URLs to OAuth

Return to **APIs & Services > Credentials**, open `Matt's Stories web`, and add both of these under **Authorised JavaScript origins** (no trailing slash):

```
https://matts-stories.web.app
https://matts-stories.firebaseapp.com
```

Click **Save**. Wait a few minutes for Google to apply the change, then reload the deployed page.

## 7. First test

1. On the deployed `https://matts-stories.web.app` page, press **Start recording**.
2. Select and sign in as `coffsmatt@gmail.com`, then approve the requested Drive and Sheets permissions.
3. Allow microphone access when the browser asks.
4. Record 15–30 seconds, press **Stop recording**, and keep the page open until it says **Saved**.
5. In Google Drive, look for the new `Matt's Stories recordings` folder. In it will be the audio file.
6. In Google Drive, look for the new `Matt's Stories recording log` Google Sheet. It will have a `Recordings` tab and a row for the test.
7. Do a 5–10 minute test on the exact iPhone and Wi-Fi that will be used. This checks both sound and upload reliability before relying on the 20-minute limit.

On iPhone, use the deployed Firebase URL—not a local preview. The page must be secure (`https`) before iOS can grant microphone access. Add the working site to the Home Screen as a one-tap shortcut.

## Everyday use

After the first sign-in and microphone approval, open the bookmark, press **Start recording**, talk, and press **Stop recording**. In the final 60 seconds, the timer flashes red. At 20:00 the recording stops automatically. Always wait for **Saved** before closing the page.

## Security and privacy choices

- The application code is public to the browser, but no private keys or credentials are included.
- The app will only accept `coffsmatt@gmail.com`; any other signed-in address is rejected before it can record or save.
- The `drive.file` permission lets this app manage only the Drive files it created, rather than every Drive file in the account.
- Keep the OAuth app in **Testing** and only list the accounts that should use it.
- The Firebase website URL is public, but it cannot access Matt’s recordings without a successful Google sign-in to the allowed account.

## Future transcription

The Sheet has `Transcription status` and `Transcript link` columns already. A Make scenario can watch new rows where the upload status is `Saved`, read the audio file URL, create a Google Doc transcription, and then write back its status and link. Keep that automation separate from the recorder so a transcription failure never affects recording.

## Updating the site

After changing any files:

```powershell
git add .
git commit -m "Describe the change"
git push
firebase deploy --only hosting
```
