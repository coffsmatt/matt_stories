/* Matt's Stories: client-only recorder using Google Identity, Drive and Sheets APIs. */
(() => {
  'use strict';
  const cfg = window.MATTS_STORIES_CONFIG;
  const SCOPES = [
    'https://www.googleapis.com/auth/drive.file',
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/userinfo.email'
  ].join(' ');
  const FOLDER_MIME = 'application/vnd.google-apps.folder';
  const SHEET_MIME = 'application/vnd.google-apps.spreadsheet';
  const $ = id => document.getElementById(id);
  const button = $('recordButton'), timer = $('timer'), status = $('status'), card = $('card');
  let accessToken = '', tokenClient, mediaRecorder, mediaStream, chunks = [];
  let startedAt, timerInterval, stopTimeout, resources;

  const pad = number => String(number).padStart(2, '0');
  const elapsed = () => startedAt ? Math.min(cfg.maxRecordingSeconds, Math.floor((Date.now() - startedAt) / 1000)) : 0;
  function renderTime(seconds) { timer.textContent = `${pad(Math.floor(seconds / 60))}:${pad(seconds % 60)}`; }
  function updateTimer() {
    const seconds = elapsed();
    renderTime(seconds);
    card.classList.toggle('warning', seconds >= cfg.maxRecordingSeconds - cfg.warningSeconds);
  }
  function setStatus(message) { status.textContent = message; }
  function resetButton() { button.disabled = false; button.textContent = 'Start recording'; card.classList.remove('warning'); }
  function fail(message) { setStatus(message); resetButton(); }
  function timestampName(mimeType) {
    const d = new Date();
    const extension = mimeType.includes('mp4') ? 'm4a' : 'webm';
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}.${pad(d.getMinutes())}.${pad(d.getSeconds())} - Matt's Story.${extension}`;
  }
  function apiError(response, label) {
    return response.json().catch(() => ({})).then(body => {
      throw new Error(`${label}: ${body.error?.message || response.statusText || 'request failed'}`);
    });
  }
  async function googleFetch(url, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set('Authorization', `Bearer ${accessToken}`);
    const response = await fetch(url, {...options, headers});
    if (!response.ok) await apiError(response, 'Google could not complete the save');
    return response;
  }
  async function requireGoogleAccess() {
    if (accessToken) return;
    if (!cfg.googleClientId || cfg.googleClientId.startsWith('PASTE-')) {
      throw new Error('The Google sign-in client ID has not been added to config.js yet.');
    }
    await new Promise((resolve, reject) => {
      const start = () => {
        tokenClient = google.accounts.oauth2.initTokenClient({
          client_id: cfg.googleClientId,
          scope: SCOPES,
          callback: async response => {
            if (response.error) return reject(new Error('Google sign-in was cancelled or not allowed.'));
            accessToken = response.access_token;
            try {
              const profile = await googleFetch('https://www.googleapis.com/oauth2/v3/userinfo');
              const user = await profile.json();
              if (user.email?.toLowerCase() !== cfg.allowedEmail.toLowerCase()) {
                accessToken = '';
                return reject(new Error(`Please sign in as ${cfg.allowedEmail}.`));
              }
              resolve();
            } catch (error) { reject(error); }
          }
        });
        tokenClient.requestAccessToken({prompt: 'consent'});
      };
      if (window.google?.accounts?.oauth2) return start();
      let attempts = 0;
      const waitForGoogle = setInterval(() => {
        if (window.google?.accounts?.oauth2) { clearInterval(waitForGoogle); start(); }
        else if (++attempts >= 20) { clearInterval(waitForGoogle); reject(new Error('Google sign-in did not load. Check your connection and reload.')); }
      }, 500);
    });
  }
  async function findDriveFile(name, mimeType) {
    const q = `name = '${name.replace(/'/g, "\\'")}' and mimeType = '${mimeType}' and trashed = false`;
    const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&spaces=drive&fields=files(id,name,webViewLink)`;
    const response = await googleFetch(url);
    const data = await response.json();
    return data.files?.[0] || null;
  }
  async function createFolder() {
    const response = await googleFetch('https://www.googleapis.com/drive/v3/files?fields=id,webViewLink', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name:cfg.folderName, mimeType:FOLDER_MIME})
    });
    return response.json();
  }
  async function createSpreadsheet() {
    const response = await googleFetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        properties:{title:cfg.spreadsheetName},
        sheets:[{properties:{title:'Recordings'}, data:[{rowData:[{values:[
          'Recorded at', 'Filename', 'Duration (seconds)', 'Audio file', 'MIME type',
          'Upload status', 'Transcription status', 'Transcript link', 'Notes'
        ].map(value => ({userEnteredValue:{stringValue:value}}))}]}]}]
      })
    });
    return response.json();
  }
  async function getResources() {
    if (resources) return resources;
    setStatus('Preparing your private story folder…');
    let folder = await findDriveFile(cfg.folderName, FOLDER_MIME);
    if (!folder) folder = await createFolder();
    let spreadsheet = await findDriveFile(cfg.spreadsheetName, SHEET_MIME);
    if (!spreadsheet) spreadsheet = await createSpreadsheet();
    resources = {folderId:folder.id, spreadsheetId:spreadsheet.id};
    return resources;
  }
  async function uploadToDrive(blob, filename, onProgress) {
    const {folderId} = await getResources();
    const start = await googleFetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,webViewLink,name', {
      method:'POST', headers:{
        'Content-Type':'application/json; charset=UTF-8',
        'X-Upload-Content-Type':blob.type || 'audio/webm',
        'X-Upload-Content-Length':String(blob.size)
      }, body:JSON.stringify({name:filename, mimeType:blob.type || 'audio/webm', parents:[folderId]})
    });
    const sessionUrl = start.headers.get('Location');
    if (!sessionUrl) throw new Error('Google did not start the upload. Please try again.');
    return new Promise((resolve, reject) => {
      const request = new XMLHttpRequest();
      request.open('PUT', sessionUrl);
      request.setRequestHeader('Content-Type', blob.type || 'audio/webm');
      request.setRequestHeader('Content-Range', `bytes 0-${blob.size - 1}/${blob.size}`);
      request.upload.onprogress = event => event.lengthComputable && onProgress(Math.round(event.loaded / event.total * 100));
      request.onerror = () => reject(new Error('The upload was interrupted. Please check Wi-Fi and try again.'));
      request.onload = () => request.status >= 200 && request.status < 300 ? resolve(JSON.parse(request.responseText)) : reject(new Error('Google could not save this recording. Please try again.'));
      request.send(blob);
    });
  }
  async function appendLog(file, durationSeconds, mimeType) {
    const {spreadsheetId} = await getResources();
    const range = encodeURIComponent('Recordings!A:I');
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;
    await googleFetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({values:[[
      new Date().toLocaleString(), file.name, Math.round(durationSeconds), file.webViewLink || `https://drive.google.com/open?id=${file.id}`,
      mimeType, 'Saved', 'Not started', '', ''
    ]]})});
  }
  async function startRecording() {
    try {
      button.disabled = true; setStatus('Connecting to your Google account…');
      await requireGoogleAccess();
      if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) throw new Error('This browser cannot record audio. Please use current Chrome or Safari.');
      mediaStream = await navigator.mediaDevices.getUserMedia({audio:true});
      const mimeType = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'].find(MediaRecorder.isTypeSupported) || '';
      mediaRecorder = new MediaRecorder(mediaStream, {mimeType, audioBitsPerSecond:24000});
      chunks = []; mediaRecorder.ondataavailable = event => event.data.size && chunks.push(event.data);
      mediaRecorder.onstop = saveRecording;
      startedAt = Date.now(); mediaRecorder.start(); updateTimer();
      timerInterval = setInterval(updateTimer, 250);
      stopTimeout = setTimeout(() => stopRecording(true), cfg.maxRecordingSeconds * 1000);
      button.disabled = false; button.textContent = 'Stop recording'; setStatus('Recording…');
    } catch (error) { fail(error.message || 'Microphone access is needed. Please allow it, then try again.'); }
  }
  function stopRecording(automatic) {
    if (!mediaRecorder || mediaRecorder.state === 'inactive') return;
    clearInterval(timerInterval); clearTimeout(stopTimeout); card.classList.remove('warning');
    renderTime(automatic ? cfg.maxRecordingSeconds : elapsed());
    button.disabled = true; button.textContent = 'Saving…';
    setStatus(automatic ? '20 minutes reached. Saving your story…' : 'Saving your story…');
    mediaRecorder.stop(); mediaStream.getTracks().forEach(track => track.stop());
  }
  async function saveRecording() {
    const durationSeconds = elapsed();
    const mimeType = mediaRecorder.mimeType || 'audio/webm';
    try {
      const file = await uploadToDrive(new Blob(chunks, {type:mimeType}), timestampName(mimeType), percent => setStatus(`Saving your story… ${percent}%`));
      await appendLog(file, durationSeconds, mimeType);
      status.replaceChildren('Saved: ');
      const link = document.createElement('a'); link.href = file.webViewLink || `https://drive.google.com/open?id=${file.id}`; link.target = '_blank'; link.rel = 'noopener'; link.textContent = file.name;
      status.append(link); resetButton();
    } catch (error) { fail(`Could not save: ${error.message || error}`); }
    finally { mediaRecorder = null; mediaStream = null; startedAt = null; }
  }
  button.addEventListener('click', () => mediaRecorder?.state === 'recording' ? stopRecording(false) : startRecording());
})();
