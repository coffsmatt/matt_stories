/*
 * Replace the value below before deployment. OAuth client IDs are public
 * identifiers, not secrets; do not put a client secret in a website.
 */
window.MATTS_STORIES_CONFIG = {
  googleClientId: "1088618610221-4hfi6i09smujtfv5a9vts5huao0l01o2.apps.googleusercontent.com",
  allowedEmail: "coffsmatt@gmail.com",
  folderName: "Matt's Stories recordings",
  spreadsheetName: "Matt's Stories recording log",
  maxRecordingSeconds: 20 * 60,
  warningSeconds: 60
};
